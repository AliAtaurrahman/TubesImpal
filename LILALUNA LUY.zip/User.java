package com.lilaluna.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class User {

    private String username;
    private String password;

    public User() {
    }

    public boolean login(String username, String password) {

        String url = "jdbc:mysql://localhost:3306/lilaluna";
        String dbUser = "root";
        String dbPassword = "";

        try {

            Connection conn = DriverManager.getConnection(
                    url,
                    dbUser,
                    dbPassword
            );

            String sql = "SELECT * FROM user "
                    + "WHERE Nama_User = ? AND password = ?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                this.username = rs.getString("Nama_User");
                this.password = rs.getString("password");

                UserSession.setUsername(this.username);

                return true;

            } else {

                return false;

            }

        } catch (Exception e) {

            System.out.println("Database error: " + e.getMessage());

            return false;
        }
    }

    public void logout() {

        this.username = null;
        this.password = null;

        UserSession.logout();

        System.out.println("User berhasil logout.");
    }
}   