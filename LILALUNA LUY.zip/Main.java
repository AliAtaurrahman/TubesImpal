package com.lilaluna.model;

public class Main {

    public static void main(String[] args) {

        System.out.println("=== TEST DATABASE ===");

        if (Koneksi.getConnection() != null) {
            System.out.println("Database berhasil terhubung.");
        } else {
            System.out.println("Database gagal terhubung.");
        }


        System.out.println();
        System.out.println("=== TEST USER ===");

        User user = new User();

        System.out.println(
                "Login: " + user.login("Erlang", "12345")
        );

        user.logout();


        System.out.println();
        System.out.println("=== TEST SESSION ===");

        UserSession session = new UserSession();

        if (session.validateSession()) {
            System.out.println("Session valid.");
        } else {
            System.out.println("Session tidak valid.");
        }


        System.out.println();
        System.out.println("=== TEST PESANAN ===");

        Pesanan pesanan = new Pesanan();

        pesanan.tambahPesanan();
        pesanan.editPesanan("P001");
        pesanan.hapusPesanan("P001");
        pesanan.cariPesanan("Erlang");
        pesanan.urutkanPesanan("tanggal");


        System.out.println();
        System.out.println("=== TEST LOG AKTIVITAS ===");

        LogAktivitas log = new LogAktivitas();

        log.simpanLog("Menambahkan pesanan");


        System.out.println();
        System.out.println("=== TEST LAPORAN ===");

        LaporanRangkuman laporan = new LaporanRangkuman();

        laporan.generateRangkuman(null);


        System.out.println();
        System.out.println("=== PROGRAM SELESAI ===");
    }
}