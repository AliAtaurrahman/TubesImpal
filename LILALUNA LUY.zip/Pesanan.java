package com.lilaluna.model;

public class Pesanan {

    private String idPesanan;
    private String namaPelanggan;
    private int jumlah;
    private double harga;
    private String tanggal;

    public Pesanan() {
    }

    public void tambahPesanan() {

        idPesanan = "P001";
        namaPelanggan = "Erlang";
        jumlah = 2;
        harga = 50000;
        tanggal = "2026-10-26";

        System.out.println("Pesanan berhasil ditambahkan.");
    }

    public void editPesanan(String id) {

        System.out.println(
                "Pesanan " + id + " berhasil diedit."
        );
    }

    public void hapusPesanan(String id) {

        System.out.println(
                "Pesanan " + id + " berhasil dihapus."
        );
    }

    public void cariPesanan(String keyword) {

        System.out.println(
                "Mencari pesanan dengan keyword: " + keyword
        );
    }

    public void urutkanPesanan(String kriteria) {

        System.out.println(
                "Pesanan diurutkan berdasarkan: " + kriteria
        );
    }
}