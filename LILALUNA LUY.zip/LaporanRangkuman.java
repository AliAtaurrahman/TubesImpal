package com.lilaluna.model;

import java.util.List;

public class LaporanRangkuman {

    private int totalPesanan;
    private double totalPendapatan;

    public LaporanRangkuman() {
    }

    public void generateRangkuman(List<Pesanan> data) {

        if (data == null) {
            totalPesanan = 0;
            totalPendapatan = 0;
        } else {
            totalPesanan = data.size();
            totalPendapatan = 0;
        }

        System.out.println("Laporan rangkuman berhasil dibuat.");
        System.out.println("Total pesanan: " + totalPesanan);
        System.out.println("Total pendapatan: " + totalPendapatan);
    }
}