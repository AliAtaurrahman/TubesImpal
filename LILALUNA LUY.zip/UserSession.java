package com.lilaluna.model;

public class UserSession {

    private static String username;

    public UserSession() {
    }

    public static void setUsername(String username) {
        UserSession.username = username;
    }

    public boolean validateSession() {

        if (username != null && !username.isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    public static void logout() {
        username = null;
    }
}